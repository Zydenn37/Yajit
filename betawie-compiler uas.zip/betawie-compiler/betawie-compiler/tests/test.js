/**
 * TEST SUITE - Kompiler Base Betawi
 * Nguji semua komponen pipeline
 */

const { Lexer } = require("../src/lexer/lexer");
const { Parser } = require("../src/parser/parser");
const { ASTPrinter } = require("../src/ast/ast");
const { SemanticAnalyzer } = require("../src/semantic/semantic");
const { Optimizer } = require("../src/optimizer/optimizer");
const { CodeGenerator } = require("../src/codegen/codegen");

let passed = 0,
  failed = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`  ✓ ${name}`);
    passed++;
  } catch (e) {
    console.log(`  ✗ ${name}`);
    console.log(`    ${e.message}`);
    failed++;
  }
}

function assert(cond, msg) {
  if (!cond) throw new Error(msg || "Assertion failed");
}

function compileCode(src) {
  const { tokens } = new Lexer(src).tokenize();
  const parser = new Parser(tokens);
  const ast = parser.parse();
  const sem = new SemanticAnalyzer();
  sem.analyze(ast);
  const opt = new Optimizer();
  const optAst = opt.optimize(JSON.parse(JSON.stringify(ast)));
  const codegen = new CodeGenerator({ header: false });
  const js = codegen.generate(optAst);
  return {
    tokens,
    ast,
    optAst,
    js,
    parseErrors: parser.errors,
    semWarnings: sem.warnings,
  };
}

// ═══════════════════════════════════════════════════════════════
console.log("\n╔══════════════════════════════════╗");
console.log("║  Test Suite Kompiler Base Betawi ║");
console.log("╚══════════════════════════════════╝\n");

// ── 1. Lexer Tests ────────────────────────────────────────────
console.log("── 1. Lexer ──");

test("Tokenisasi keyword isi", () => {
  const { tokens } = new Lexer("isi x = 10").tokenize();
  assert(tokens[0].type === "VAR", "Token pertama harus VAR");
  assert(tokens[1].type === "IDENT", "Token kedua harus IDENT");
  assert(tokens[2].type === "OP", "Token ketiga harus OP");
  assert(tokens[3].type === "NUMBER", "Token keempat harus NUMBER");
});

test("Tokenisasi keyword kalo/kalo_kagak", () => {
  const { tokens } = new Lexer("kalo (x) {} kalo_kagak {}").tokenize();
  const types = tokens.map((t) => t.type);
  assert(types.includes("IF"), "Harus ada IF");
  assert(types.includes("ELSE"), "Harus ada ELSE");
});

test("Tokenisasi string", () => {
  const { tokens } = new Lexer('"Halo Bro!"').tokenize();
  assert(tokens[0].type === "STRING", "Harus STRING");
  assert(tokens[0].value === '"Halo Bro!"', "Nilai harus bener");
});

test("Tokenisasi boolean bener/salah", () => {
  const { tokens } = new Lexer("bener salah").tokenize();
  assert(tokens[0].type === "BOOL_TRUE", "bener harus BOOL_TRUE");
  assert(tokens[1].type === "BOOL_FALSE", "salah harus BOOL_FALSE");
});

test("Tokenisasi deretan (array)", () => {
  const { tokens } = new Lexer("deretan[1, 2, 3]").tokenize();
  assert(tokens[0].type === "ARRAY", "Harus ARRAY");
});

test("Lewatin komentar baris", () => {
  const { tokens } = new Lexer("// ini komentar\nisi x = 1").tokenize();
  assert(tokens[0].type === "VAR", "Komentar harus dilewatin");
});

test("Lewatin komentar blok", () => {
  const { tokens } = new Lexer("/* blok */ isi y = 2").tokenize();
  assert(tokens[0].type === "VAR", "Komentar blok harus dilewatin");
});

// ── 2. Parser Tests ───────────────────────────────────────────
console.log("\n── 2. Parser ──");

test("Parse deklarasi variabel", () => {
  const r = compileCode("isi x = 42");
  assert(r.ast.body[0].type === "VarDecl", "Harus VarDecl");
  assert(r.ast.body[0].name === "x", "Nama harus x");
  assert(r.ast.body[0].init.value === 42, "Nilai harus 42");
});

test("Parse fungsi", () => {
  const r = compileCode("fungsi tambah(a, b) { balikin a + b }");
  assert(r.ast.body[0].type === "FuncDecl", "Harus FuncDecl");
  assert(r.ast.body[0].name === "tambah", "Nama harus tambah");
  assert(r.ast.body[0].params.length === 2, "Harus 2 parameter");
});

test("Parse if/else", () => {
  const r = compileCode(
    'kalo (x > 0) { tulis("positif") } kalo_kagak { tulis("negatif") }',
  );
  assert(r.ast.body[0].type === "If", "Harus If");
  assert(r.ast.body[0].alternate !== null, "Harus ada else");
});

test("Parse while loop", () => {
  const r = compileCode("selame (i < 10) { i = i + 1 }");
  assert(r.ast.body[0].type === "While", "Harus While");
});

test("Parse array literal", () => {
  const r = compileCode("isi arr = deretan[1, 2, 3]");
  assert(r.ast.body[0].init.type === "ArrayLit", "Harus ArrayLit");
  assert(r.ast.body[0].init.elements.length === 3, "Harus 3 elemen");
});

test("Parse nested function call", () => {
  const r = compileCode("tulis(tambah(1, 2))");
  assert(r.parseErrors.length === 0, "Kagak ada error parsing");
});

// ── 3. AST Tests ─────────────────────────────────────────────
console.log("\n── 3. AST ──");

test("ASTPrinter ngasilin string", () => {
  const r = compileCode("isi x = 5");
  const printed = ASTPrinter.print(r.ast);
  assert(typeof printed === "string", "Harus string");
  assert(printed.includes("VarDecl"), "Harus ada VarDecl");
});

test("AST stats ngitung node", () => {
  const r = compileCode("isi x = 5\nisi y = 10");
  const stats = ASTPrinter.stats(r.ast);
  assert(stats["VarDecl"] === 2, "Harus 2 VarDecl");
});

test("AST depth minimal 2", () => {
  const r = compileCode("isi x = 5");
  const d = ASTPrinter.depth(r.ast);
  assert(d >= 2, "Kedalaman minimal 2");
});

// ── 4. Semantic Tests ─────────────────────────────────────────
console.log("\n── 4. Semantic Analysis ──");

test("Deteksi variabel undeclared", () => {
  const r = compileCode("tulis(xKagakAde)");
  assert(
    r.semWarnings.some((w) => w.includes("xKagakAde")),
    "Harus ada warning undeclared",
  );
});

test("Kagak ada error untuk kode valid", () => {
  const r = compileCode("isi x = 10\ntulis(x)");
  const sem = new SemanticAnalyzer();
  const { tokens } = new Lexer("isi x = 10\ntulis(x)").tokenize();
  const ast = new Parser(tokens).parse();
  sem.analyze(ast);
  assert(sem.errors.length === 0, "Kagak boleh ada error");
});

test("Deteksi berhenti di luar loop", () => {
  const src = "berhenti";
  const { tokens } = new Lexer(src).tokenize();
  const ast = new Parser(tokens).parse();
  const sem = new SemanticAnalyzer();
  sem.analyze(ast);
  assert(sem.errors.length > 0, "Harus ada error berhenti di luar loop");
});

// ── 5. Optimizer Tests ────────────────────────────────────────
console.log("\n── 5. Optimizer ──");

test("Constant folding angka", () => {
  const { tokens } = new Lexer("isi x = 2 + 3").tokenize();
  const ast = new Parser(tokens).parse();
  const opt = new Optimizer();
  const optimized = opt.optimize(JSON.parse(JSON.stringify(ast)));
  assert(opt.getStats().constantsFolded > 0, "Harus ada constant folding");
  assert(optimized.body[0].init.value === 5, "Harus jadi 5");
});

test("Identity elimination x * 1", () => {
  const { tokens } = new Lexer("isi y = x * 1").tokenize();
  const ast = new Parser(tokens).parse();
  const opt = new Optimizer();
  const optimized = opt.optimize(JSON.parse(JSON.stringify(ast)));
  assert(opt.getStats().identitiesRemoved > 0, "Harus ada identity removal");
});

test("Dead code elimination kalo(salah)", () => {
  const { tokens } = new Lexer(
    'kalo (salah) { tulis("kagak ketemu") }',
  ).tokenize();
  const ast = new Parser(tokens).parse();
  const opt = new Optimizer();
  opt.optimize(JSON.parse(JSON.stringify(ast)));
  assert(opt.getStats().deadCodeRemoved > 0, "Harus ada dead code removal");
});

// ── 6. Code Generation Tests ──────────────────────────────────
console.log("\n── 6. Code Generator ──");

test("Generate let dari isi", () => {
  const r = compileCode("isi x = 10");
  assert(r.js.includes("let x = 10"), 'Harus ada "let x = 10"');
});

test("Generate function dari fungsi", () => {
  const r = compileCode('fungsi salam(name) { tulis("Halo " + name) }');
  assert(r.js.includes("function salam(name)"), 'Harus ada "function salam"');
});

test("Generate console.log dari tulis", () => {
  const r = compileCode('tulis("Halo Dunia!")');
  assert(r.js.includes("console.log"), "Harus ada console.log");
});

test("Generate if/else", () => {
  const r = compileCode(
    'kalo (x > 0) { tulis("ok") } kalo_kagak { tulis("no") }',
  );
  assert(r.js.includes("if ("), "Harus ada if");
  assert(r.js.includes("} else {"), "Harus ada else");
});

test("Generate while dari selame", () => {
  const r = compileCode("selame (i < 5) { i = i + 1 }");
  assert(r.js.includes("while ("), "Harus ada while");
});

test("Generate array literal", () => {
  const r = compileCode("isi arr = deretan[1, 2, 3]");
  assert(r.js.includes("[1, 2, 3]"), "Harus ada array literal");
});

// ── Summary ───────────────────────────────────────────────────
console.log("\n╔══════════════════════════════════╗");
console.log(
  `║  Hasil: ${String(passed).padStart(2)} lulus, ${String(failed).padStart(2)} gagal           ║`,
);
console.log("╚══════════════════════════════════╝\n");

if (failed > 0) process.exit(1);