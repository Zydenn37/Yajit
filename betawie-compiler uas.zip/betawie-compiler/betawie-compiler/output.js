// ================================================
// Dihasilin ame Kompiler Base Betawi → JavaScript
// Tanggal: 29/6/2026, 09.10.08
// ================================================

function fibonacci(n) {
  if ((n <= 0)) {
    return 0;
  }
  if ((n == 1)) {
    return 1;
  }
  let a = 0;
  let b = 1;
  let i = 2;
  while ((i <= n)) {
    let c = (a + b);
    a = b;
    b = c;
    i = (i + 1);
  }
  return b;
}

function isPrima(n) {
  if ((n < 2)) {
    return false;
  }
  let i = 2;
  while (((i * i) <= n)) {
    if (((n % i) == 0)) {
      return false;
    }
    i = (i + 1);
  }
  return true;
}

function rerata(arr, n) {
  let total = 0;
  let i = 0;
  while ((i < n)) {
    total = (total + arr[i]);
    i = (i + 1);
  }
  return (total / n);
}

function maksimum(arr, n) {
  let maks = arr[0];
  let i = 1;
  while ((i < n)) {
    if ((arr[i] > maks)) {
      maks = arr[i];
    }
    i = (i + 1);
  }
  return maks;
}

console.log("=== Deretan Fibonacci ===");
let i = 0;
while ((i <= 10)) {
  console.log(((("F(" + i) + ") = ") + fibonacci(i)));
  i = (i + 1);
}
console.log("");
console.log("=== Bilangan Prima 1-50 ===");
let bilangan = 2;
let listPrima = "";
while ((bilangan <= 50)) {
  if (isPrima(bilangan)) {
    listPrima = ((listPrima + bilangan) + " ");
  }
  bilangan = (bilangan + 1);
}
console.log(listPrima);
console.log("");
console.log("=== Statistik ===");
let nilai = [85, 92, 78, 95, 88, 76, 90, 83, 87, 91];
let jml = 10;
console.log("Nilai: 85 92 78 95 88 76 90 83 87 91");
console.log(("Rerata: " + rerata(nilai, jml)));
console.log(("Nilai tertinggi: " + maksimum(nilai, jml)));