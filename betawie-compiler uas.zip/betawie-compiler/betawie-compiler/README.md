---

## 📊 Pembagian Bobot Nilai

| Komponen              | File                         | Bobot    |
| --------------------- | ---------------------------- | -------- |
| Desain Base/Grammar   | `docs/grammar.md`            | 10%      |
| Lexer                 | `src/lexer/lexer.js`         | 15%      |
| Parser                | `src/parser/parser.js`       | 15%      |
| AST                   | `src/ast/ast.js`             | 10%      |
| Semantic + Optimizer  | `src/semantic/semantic.js`   | 10%      |
| Code Optimization     | `src/optimizer/optimizer.js` | 10%      |
| Code Generation       | `src/codegen/codegen.js`     | 10%      |
| Dokumentasi (Video)   | YouTube                      | 20%      |
| **Total**             |                              | **100%** |

---

## 🔑 Keyword Lengkap

| Betawi      | JavaScript  |
| ----------- | ----------- |
| isi         | let         |
| fungsi      | function    |
| balikin     | return      |
| kalo        | if          |
| kalo_kagak  | else        |
| selame      | while       |
| buat        | for         |
| tulis       | console.log |
| bener       | true        |
| salah       | false       |
| deretan     | array []    |
| ame         | &&          |
| atau        | \|\|        |
| kagak       | !           |
| berhenti    | break       |
| lanjutin    | continue    |

---

_Dibuat buat Tugas UAS — Kompiler Base Betawi_