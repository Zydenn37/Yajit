/**
 * SEMANTIC ANALYZER - Komponen 4
 * Tugas: Analisis semantik — type checking, scope checking, validasi
 *
 * Bobot: 10% (semantic) + 10% (code optimization)
 */

class SemanticError extends Error {
  constructor(msg, line) {
    super(`[Semantic] Baris ${line || "?"} — ${msg}`);
    this.line = line;
  }
}

class Scope {
  constructor(parent = null, name = "global") {
    this.parent = parent;
    this.name = name;
    this.symbols = new Map(); // name → { type, value, line }
  }

  define(name, meta) {
    this.symbols.set(name, meta);
  }

  lookup(name) {
    if (this.symbols.has(name)) return this.symbols.get(name);
    if (this.parent) return this.parent.lookup(name);
    return null;
  }

  isDeclaredInCurrent(name) {
    return this.symbols.has(name);
  }
}

class SemanticAnalyzer {
  constructor() {
    this.globalScope = new Scope(null, "global");
    this.currentScope = this.globalScope;
    this.errors = [];
    this.warnings = [];
    this.functions = new Map(); // name → { params, line }
    this.inLoop = false;
    this.inFunction = false;
    this.returnFound = false;
  }

  error(msg, line) {
    this.errors.push(new SemanticError(msg, line));
  }
  warn(msg, line) {
    this.warnings.push(`Peringatan baris ${line || "?"}: ${msg}`);
  }

  pushScope(name) {
    this.currentScope = new Scope(this.currentScope, name);
  }
  popScope() {
    this.currentScope = this.currentScope.parent;
  }

  // ─── Main entry ─────────────────────────────────────────────────
  analyze(node) {
    if (!node) return "any";
    switch (node.type) {
      case "Program":
        return this.analyzeProgram(node);
      case "FuncDecl":
        return this.analyzeFuncDecl(node);
      case "VarDecl":
        return this.analyzeVarDecl(node);
      case "Block":
        return this.analyzeBlock(node);
      case "If":
        return this.analyzeIf(node);
      case "While":
        return this.analyzeWhile(node);
      case "For":
        return this.analyzeFor(node);
      case "Return":
        return this.analyzeReturn(node);
      case "Print":
        return this.analyzePrint(node);
      case "ExprStmt":
        return this.analyze(node.expr);
      case "Assign":
        return this.analyzeAssign(node);
      case "BinOp":
        return this.analyzeBinOp(node);
      case "Unary":
        return this.analyzeUnary(node);
      case "Postfix":
        return this.analyze(node.operand);
      case "Call":
        return this.analyzeCall(node);
      case "Index":
        return this.analyzeIndex(node);
      case "Member":
        return this.analyze(node.object);
      case "ArrayLit":
        node.elements.forEach((e) => this.analyze(e));
        return "array";
      case "Ident":
        return this.analyzeIdent(node);
      case "Num":
        return "number";
      case "Str":
        return "string";
      case "Bool":
        return "boolean";
      case "Null":
        return "null";
      case "Break":
        if (!this.inLoop) this.error(`'eureun' di luar loop`, node.line);
        return "void";
      case "Continue":
        if (!this.inLoop) this.error(`'teruskeun' di luar loop`, node.line);
        return "void";
      default:
        return "any";
    }
  }

  analyzeProgram(node) {
    // First pass: collect all function declarations
    node.body
      .filter((s) => s.type === "FuncDecl")
      .forEach((fn) => {
        if (this.functions.has(fn.name)) {
          this.warn(`Fungsi '${fn.name}' dideklarasikeun deui`, fn.line);
        }
        this.functions.set(fn.name, { params: fn.params, line: fn.line });
        this.globalScope.define(fn.name, { type: "function", line: fn.line });
      });
    // Second pass: analyze all
    node.body.forEach((s) => this.analyze(s));
    return "void";
  }

  analyzeFuncDecl(node) {
    const prevFunc = this.inFunction;
    this.inFunction = true;
    this.returnFound = false;
    this.pushScope(`func:${node.name}`);
    node.params.forEach((p) =>
      this.currentScope.define(p, { type: "param", line: node.line }),
    );
    this.analyze(node.body);
    this.popScope();
    this.inFunction = prevFunc;
    return "void";
  }

  analyzeVarDecl(node) {
    if (this.currentScope.isDeclaredInCurrent(node.name)) {
      this.warn(
        `Variabel '${node.name}' dideklarasikeun deui dina scope ieu`,
        node.line,
      );
    }
    const initType = node.init ? this.analyze(node.init) : "undefined";
    this.currentScope.define(node.name, { type: initType, line: node.line });
    return "void";
  }

  analyzeBlock(node) {
    this.pushScope("block");
    node.body.forEach((s) => this.analyze(s));
    this.popScope();
    return "void";
  }

  analyzeIf(node) {
    this.analyze(node.test);
    this.analyze(node.consequent);
    if (node.alternate) this.analyze(node.alternate);
    return "void";
  }

  analyzeWhile(node) {
    this.analyze(node.test);
    const prev = this.inLoop;
    this.inLoop = true;
    this.analyze(node.body);
    this.inLoop = prev;
    return "void";
  }

  analyzeFor(node) {
    this.pushScope("for");
    if (node.init) this.analyze(node.init);
    this.analyze(node.test);
    this.analyze(node.update);
    const prev = this.inLoop;
    this.inLoop = true;
    this.analyze(node.body);
    this.inLoop = prev;
    this.popScope();
    return "void";
  }

  analyzeReturn(node) {
    if (!this.inFunction) this.error(`'balik' di luar fungsi`, node.line);
    this.returnFound = true;
    if (node.value) this.analyze(node.value);
    return "void";
  }

  analyzePrint(node) {
    node.args.forEach((a) => this.analyze(a));
    return "void";
  }

  analyzeAssign(node) {
    const rightType = this.analyze(node.right);
    if (node.left.type === "Ident") {
      const sym = this.currentScope.lookup(node.left.name);
      if (!sym)
        this.warn(
          `Variabel '${node.left.name}' can can dideklarasikeun`,
          node.line,
        );
    }
    this.analyze(node.left);
    return rightType;
  }

  analyzeBinOp(node) {
    const lType = this.analyze(node.left);
    const rType = this.analyze(node.right);
    const numericOps = ["-", "*", "/", "%", "<", ">", "<=", ">="];
    if (numericOps.includes(node.op)) {
      if (lType !== "number" && lType !== "any")
        this.warn(`Operator '${node.op}' diharepkeun angka`, node.left.line);
      if (rType !== "number" && rType !== "any")
        this.warn(`Operator '${node.op}' diharepkeun angka`, node.right.line);
      return node.op.match(/[<>!=]/) ? "boolean" : "number";
    }
    if (node.op === "+")
      return lType === "string" || rType === "string" ? "string" : "number";
    if (["==", "!="].includes(node.op)) return "boolean";
    if (["&&", "||"].includes(node.op)) return "boolean";
    return "any";
  }

  analyzeUnary(node) {
    const t = this.analyze(node.operand);
    if (node.op === "-" && t !== "number" && t !== "any")
      this.warn(`Operator '-' butuh angka`, node.line);
    return node.op === "!" ? "boolean" : t;
  }

  analyzeCall(node) {
    const calleeType = this.analyze(node.callee);
    node.args.forEach((a) => this.analyze(a));
    if (node.callee.type === "Ident") {
      const fn = this.functions.get(node.callee.name);
      if (fn) {
        if (fn.params.length !== node.args.length) {
          this.warn(
            `Fungsi '${node.callee.name}' butuh ${fn.params.length} argumen, meunang ${node.args.length}`,
            node.callee.line,
          );
        }
      }
    }
    return "any";
  }

  analyzeIndex(node) {
    this.analyze(node.object);
    const idxType = this.analyze(node.index);
    if (idxType !== "number" && idxType !== "any")
      this.warn(`Index array kudu angka`, node.index?.line);
    return "any";
  }

  analyzeIdent(node) {
    const sym = this.currentScope.lookup(node.name);
    if (!sym) {
      // Allow known globals
      const jsGlobals = new Set([
        "console",
        "Math",
        "parseInt",
        "parseFloat",
        "String",
        "Number",
        "Boolean",
        "Array",
        "Object",
        "JSON",
        "Date",
        "typeof",
        "undefined",
        "NaN",
        "Infinity",
      ]);
      if (!jsGlobals.has(node.name)) {
        this.warn(
          `Identifier '${node.name}' teu kapanggih dina scope`,
          node.line,
        );
      }
    }
    return sym?.type || "any";
  }

  getReport() {
    return {
      errors: this.errors,
      warnings: this.warnings,
      functions: Object.fromEntries(this.functions),
      symbolCount: this.globalScope.symbols.size,
    };
  }
}

module.exports = { SemanticAnalyzer, SemanticError, Scope };
