/**
 * PARSER - Komponen 2
 * Tugas: Ngubah token-token jadi AST (Abstract Syntax Tree)
 * Metode: Recursive Descent Parsing
 *
 * Bobot: 15%
 */

class ParseError extends Error {
  constructor(msg, line, col) {
    super(`[Parser] Baris ${line}:${col} — ${msg}`);
    this.line = line;
    this.col = col;
  }
}

class Parser {
  constructor(tokens) {
    this.tokens = tokens.filter((t) => t.type !== "EOF" || true);
    this.pos = 0;
    this.errors = [];
  }

  // ─── Helpers ───────────────────────────────────────────────────
  peek() {
    return this.tokens[this.pos] || { type: "EOF", value: "", line: 0, col: 0 };
  }
  prev() {
    return this.tokens[this.pos - 1];
  }
  isEOF() {
    return this.peek().type === "EOF";
  }

  next() {
    const t = this.tokens[this.pos];
    if (this.pos < this.tokens.length - 1) this.pos++;
    return t;
  }

  check(type, value = null) {
    const t = this.peek();
    return t.type === type && (value === null || t.value === value);
  }

  match(type, value = null) {
    if (this.check(type, value)) {
      this.next();
      return true;
    }
    return false;
  }

  expect(type, value = null) {
    if (this.check(type, value)) return this.next();
    const t = this.peek();
    const expected = value ? `'${value}'` : type;
    const err = new ParseError(
      `Diharapin ${expected}, dapetnya '${t.value}' (${t.type})`,
      t.line,
      t.col,
    );
    this.errors.push(err);
    return null;
  }

  // Skip token sampe nemu sync point (error recovery)
  synchronize() {
    const syncTypes = new Set([
      "RBRACE",
      "FUNC",
      "VAR",
      "IF",
      "WHILE",
      "FOR",
      "RETURN",
      "PRINT",
      "EOF",
    ]);
    while (!this.isEOF()) {
      if (syncTypes.has(this.peek().type)) return;
      this.next();
    }
  }

  // ─── Top Level ─────────────────────────────────────────────────
  parse() {
    const body = [];
    while (!this.isEOF()) {
      try {
        body.push(this.parseStatement());
      } catch (e) {
        this.errors.push(e);
        this.synchronize();
      }
    }
    return { type: "Program", body };
  }

  // ─── Statements ────────────────────────────────────────────────
  parseStatement() {
    const t = this.peek();
    switch (t.type) {
      case "FUNC":
        return this.parseFuncDecl();
      case "VAR":
        return this.parseVarDecl();
      case "IF":
        return this.parseIf();
      case "WHILE":
        return this.parseWhile();
      case "FOR":
        return this.parseFor();
      case "RETURN":
        return this.parseReturn();
      case "PRINT":
        return this.parsePrint();
      case "BREAK":
        this.next();
        return { type: "Break", line: t.line };
      case "CONTINUE":
        this.next();
        return { type: "Continue", line: t.line };
      case "LBRACE":
        return this.parseBlock();
      default:
        return this.parseExprStatement();
    }
  }

  parseFuncDecl() {
    const tok = this.next(); // makan 'fungsi'
    const name = this.expect("IDENT");
    this.expect("LPAREN");
    const params = [];
    while (!this.check("RPAREN") && !this.isEOF()) {
      const p = this.expect("IDENT");
      if (p) params.push(p.value);
      if (!this.match("COMMA")) break;
    }
    this.expect("RPAREN");
    const body = this.parseBlock();
    return {
      type: "FuncDecl",
      name: name?.value,
      params,
      body,
      line: tok.line,
    };
  }

  parseVarDecl() {
    const tok = this.next(); // makan 'isi'
    const name = this.expect("IDENT");
    let init = null;
    if (this.check("OP", "=")) {
      this.next();
      init = this.parseExpr();
    }
    return { type: "VarDecl", name: name?.value, init, line: tok.line };
  }

  parseIf() {
    const tok = this.next(); // makan 'kalo'
    this.expect("LPAREN");
    const test = this.parseExpr();
    this.expect("RPAREN");
    const consequent = this.parseBlock();
    let alternate = null;
    if (this.peek().type === "ELSE") {
      this.next();
      alternate =
        this.peek().type === "IF" ? this.parseIf() : this.parseBlock();
    }
    return { type: "If", test, consequent, alternate, line: tok.line };
  }

  parseWhile() {
    const tok = this.next(); // makan 'selame'
    this.expect("LPAREN");
    const test = this.parseExpr();
    this.expect("RPAREN");
    const body = this.parseBlock();
    return { type: "While", test, body, line: tok.line };
  }

  parseFor() {
    const tok = this.next(); // makan 'buat'
    this.expect("LPAREN");
    let init = null;
    if (!this.check("SEMI")) {
      init =
        this.peek().type === "VAR"
          ? this.parseVarDecl()
          : this.parseExprStatement(true);
    }
    this.expect("SEMI");
    const test = this.parseExpr();
    this.expect("SEMI");
    const update = this.parseExpr();
    this.expect("RPAREN");
    const body = this.parseBlock();
    return { type: "For", init, test, update, body, line: tok.line };
  }

  parseReturn() {
    const tok = this.next(); // makan 'balikin'
    const noVal =
      this.check("RBRACE") || this.check("EOF") || this.check("SEMI");
    const value = noVal ? null : this.parseExpr();
    return { type: "Return", value, line: tok.line };
  }

  parsePrint() {
    const tok = this.next(); // makan 'tulis'
    this.expect("LPAREN");
    const args = [];
    while (!this.check("RPAREN") && !this.isEOF()) {
      args.push(this.parseExpr());
      if (!this.match("COMMA")) break;
    }
    this.expect("RPAREN");
    return { type: "Print", args, line: tok.line };
  }

  parseBlock() {
    const tok = this.expect("LBRACE");
    const body = [];
    while (!this.check("RBRACE") && !this.isEOF()) {
      try {
        body.push(this.parseStatement());
      } catch (e) {
        this.errors.push(e);
        this.synchronize();
      }
    }
    this.expect("RBRACE");
    return { type: "Block", body, line: tok?.line };
  }

  parseExprStatement(noSemi = false) {
    const expr = this.parseExpr();
    this.match("SEMI");
    return { type: "ExprStmt", expr };
  }

  // ─── Expressions (Precedence Climbing) ─────────────────────────
  parseExpr() {
    return this.parseAssign();
  }

  parseAssign() {
    let left = this.parseOr();
    if (this.check("OP", "=")) {
      const tok = this.next();
      const right = this.parseAssign();
      return { type: "Assign", left, right, line: tok.line };
    }
    // Compound assignment: +=, -=, *=, /=
    const compound = { "+=": "+", "-=": "-", "*=": "*", "/=": "/" };
    if (this.peek().type === "OP" && compound[this.peek().value]) {
      const tok = this.next();
      const op = compound[tok.value];
      const right = this.parseAssign();
      return {
        type: "Assign",
        left,
        right: { type: "BinOp", op, left, right },
        line: tok.line,
      };
    }
    return left;
  }

  parseOr() {
    let left = this.parseAnd();
    while (this.check("OP", "||") || this.peek().type === "OR") {
      const op = this.next().value;
      left = { type: "BinOp", op: "||", left, right: this.parseAnd() };
    }
    return left;
  }

  parseAnd() {
    let left = this.parseEquality();
    while (this.check("OP", "&&") || this.peek().type === "AND") {
      const op = this.next().value;
      left = { type: "BinOp", op: "&&", left, right: this.parseEquality() };
    }
    return left;
  }

  parseEquality() {
    let left = this.parseRelational();
    while (this.check("OP", "==") || this.check("OP", "!=")) {
      const op = this.next().value;
      left = { type: "BinOp", op, left, right: this.parseRelational() };
    }
    return left;
  }

  parseRelational() {
    let left = this.parseAdditive();
    while (
      this.peek().type === "OP" &&
      ["<", ">", "<=", ">="].includes(this.peek().value)
    ) {
      const op = this.next().value;
      left = { type: "BinOp", op, left, right: this.parseAdditive() };
    }
    return left;
  }

  parseAdditive() {
    let left = this.parseMultiplicative();
    while (this.check("OP", "+") || this.check("OP", "-")) {
      const op = this.next().value;
      left = { type: "BinOp", op, left, right: this.parseMultiplicative() };
    }
    return left;
  }

  parseMultiplicative() {
    let left = this.parseUnary();
    while (
      this.check("OP", "*") ||
      this.check("OP", "/") ||
      this.check("OP", "%")
    ) {
      const op = this.next().value;
      left = { type: "BinOp", op, left, right: this.parseUnary() };
    }
    return left;
  }

  parseUnary() {
    if (
      this.check("OP", "-") ||
      this.check("OP", "!") ||
      this.peek().type === "NOT"
    ) {
      const tok = this.next();
      const op = tok.value === "kagak" ? "!" : tok.value;
      return { type: "Unary", op, operand: this.parseUnary(), line: tok.line };
    }
    return this.parsePostfix();
  }

  parsePostfix() {
    let expr = this.parseCall();
    while (this.check("OP", "++") || this.check("OP", "--")) {
      const op = this.next().value;
      expr = { type: "Postfix", op, operand: expr };
    }
    return expr;
  }

  parseCall() {
    let expr = this.parsePrimary();
    while (true) {
      if (this.check("LPAREN")) {
        this.next();
        const args = [];
        while (!this.check("RPAREN") && !this.isEOF()) {
          args.push(this.parseExpr());
          if (!this.match("COMMA")) break;
        }
        this.expect("RPAREN");
        expr = { type: "Call", callee: expr, args };
      } else if (this.check("LBRACKET")) {
        this.next();
        const index = this.parseExpr();
        this.expect("RBRACKET");
        expr = { type: "Index", object: expr, index };
      } else if (this.check("DOT")) {
        this.next();
        const prop = this.expect("IDENT");
        expr = { type: "Member", object: expr, property: prop?.value };
      } else break;
    }
    return expr;
  }

  parsePrimary() {
    const t = this.peek();

    if (t.type === "NUMBER") {
      this.next();
      return { type: "Num", value: parseFloat(t.value), line: t.line };
    }
    if (t.type === "STRING") {
      this.next();
      return { type: "Str", value: t.value, line: t.line };
    }
    if (t.type === "BOOL_TRUE") {
      this.next();
      return { type: "Bool", value: true, line: t.line };
    }
    if (t.type === "BOOL_FALSE") {
      this.next();
      return { type: "Bool", value: false, line: t.line };
    }
    if (t.type === "NULL") {
      this.next();
      return { type: "Null", line: t.line };
    }

    if (t.type === "ARRAY") {
      this.next();
      this.expect("LBRACKET");
      const elements = [];
      while (!this.check("RBRACKET") && !this.isEOF()) {
        elements.push(this.parseExpr());
        if (!this.match("COMMA")) break;
      }
      this.expect("RBRACKET");
      return { type: "ArrayLit", elements, line: t.line };
    }

    if (t.type === "IDENT") {
      this.next();
      return { type: "Ident", name: t.value, line: t.line };
    }

    if (t.type === "LPAREN") {
      this.next();
      const expr = this.parseExpr();
      this.expect("RPAREN");
      return expr;
    }

    this.next();
    throw new ParseError(
      `Ekspresi kagak valid: '${t.value}' (${t.type})`,
      t.line,
      t.col,
    );
  }
}

module.exports = { Parser, ParseError };