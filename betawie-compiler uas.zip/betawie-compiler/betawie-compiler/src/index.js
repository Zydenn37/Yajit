#!/usr/bin/env node
/**
 * BETAWI COMPILER - Entry Point CLI
 * ================================
 * Cara make:
 *   node src/index.js <file.betawi>
 *   node src/index.js <file.betawi> --tokens
 *   node src/index.js <file.betawi> --ast
 *   node src/index.js <file.betawi> --semantic
 *   node src/index.js <file.betawi> --out output.js
 *   node src/index.js <file.betawi> --all
 */

const fs = require("fs");
const path = require("path");
const { Lexer } = require("./lexer/lexer");
const { Parser } = require("./parser/parser");
const { ASTPrinter } = require("./ast/ast");
const { SemanticAnalyzer } = require("./semantic/semantic");
const { Optimizer } = require("./optimizer/optimizer");
const { CodeGenerator } = require("./codegen/codegen");

// ── ANSI Colors ─────────────────────────────────────────────────────
const C = {
  reset: "\x1b[0m",
  red: "\x1b[31m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  blue: "\x1b[34m",
  cyan: "\x1b[36m",
  bold: "\x1b[1m",
  gray: "\x1b[90m",
};
const clr = (color, text) => `${color}${text}${C.reset}`;

// ── Help ─────────────────────────────────────────────────────────────
function showHelp() {
  console.log(`
${clr(C.bold + C.cyan, "╔══════════════════════════════════════╗")}
${clr(C.bold + C.cyan, "║   Kompiler Base Betawi → JavaScript  ║")}
${clr(C.bold + C.cyan, "╚══════════════════════════════════════╝")}

${clr(C.bold, "Cara Make:")}
  node src/index.js <file.betawi> [pilihan]

${clr(C.bold, "Pilihan:")}
  --tokens     Tampilín daftar token (hasil Lexer)
  --ast        Tampilín Abstract Syntax Tree
  --semantic   Tampilín laporan analisis semantik
  --optimize   Tampilín statistik optimasi
  --out <file> Simpen output JavaScript ke file
  --all        Tampilín semua tahapan
  --help       Tampilín bantuan ini

${clr(C.bold, "Contoh:")}
  node src/index.js examples/hello.betawi
  node src/index.js examples/fibonacci.betawi --all
  node src/index.js examples/factorial.betawi --out output.js

${clr(C.bold, "Ekstensi file:")} .betawi
`);
}

// ── Main Compiler Pipeline ────────────────────────────────────────────
function compile(source, options = {}) {
  const result = {
    tokens: null,
    ast: null,
    semantic: null,
    optimized: null,
    js: null,
    errors: [],
    warnings: [],
    success: false,
  };

  console.log(clr(C.cyan, "\n⬡ Betawi Compiler — Mulai pipeline...\n"));

  // ── Step 1: Lexing ────────────────────────────────────────────────
  console.log(clr(C.bold, "[ 1/5 ] Lexer — Tokenisasi source code..."));
  const lexer = new Lexer(source);
  const { tokens, errors: lexErrors } = lexer.tokenize();
  result.tokens = tokens;

  if (lexErrors.length > 0) {
    console.log(clr(C.red, `  ✗ ${lexErrors.length} kesalahan lexer:`));
    lexErrors.forEach((e) => console.log(clr(C.red, `    ${e.message}`)));
    result.errors.push(...lexErrors);
  } else {
    console.log(clr(C.green, `  ✓ ${tokens.length - 1} token dihasilin`));
  }

  if (options.showTokens) {
    console.log(clr(C.gray, "\n  ── Token List ──"));
    tokens.forEach((t) => {
      if (t.type === "EOF") return;
      console.log(
        clr(
          C.gray,
          `  L${String(t.line).padStart(3)}:C${String(t.col).padStart(2)}  ${t.type.padEnd(14)} "${t.value}"`,
        ),
      );
    });
    console.log();
  }

  // ── Step 2: Parsing ───────────────────────────────────────────────
  console.log(clr(C.bold, "[ 2/5 ] Parser — Nyusun AST..."));
  const parser = new Parser(tokens);
  const ast = parser.parse();
  result.ast = ast;

  const parseErrors = [...lexErrors, ...parser.errors];
  if (parser.errors.length > 0) {
    console.log(clr(C.red, `  ✗ ${parser.errors.length} kesalahan parser:`));
    parser.errors.forEach((e) => console.log(clr(C.red, `    ${e.message}`)));
    result.errors.push(...parser.errors);
  } else {
    const depth = ASTPrinter.depth(ast);
    const stats = ASTPrinter.stats(ast);
    const nodeCount = Object.values(stats).reduce((a, b) => a + b, 0);
    console.log(
      clr(
        C.green,
        `  ✓ AST dihasilin — ${nodeCount} node, kedalaman ${depth}`,
      ),
    );
  }

  if (options.showAST) {
    console.log(clr(C.gray, "\n  ── AST ──"));
    console.log(ASTPrinter.print(ast));
  }

  // ── Step 3: Semantic Analysis ─────────────────────────────────────
  console.log(clr(C.bold, "[ 3/5 ] Semantic Analysis..."));
  const sem = new SemanticAnalyzer();
  sem.analyze(ast);
  const semReport = sem.getReport();
  result.semantic = semReport;

  semReport.warnings.forEach((w) => {
    console.log(clr(C.yellow, `  ⚠ ${w}`));
    result.warnings.push(w);
  });
  if (semReport.errors.length > 0) {
    semReport.errors.forEach((e) => {
      console.log(clr(C.red, `  ✗ ${e.message}`));
      result.errors.push(e);
    });
  } else {
    const fnNames = Object.keys(semReport.functions);
    console.log(
      clr(
        C.green,
        `  ✓ Semantik valid — ${semReport.symbolCount} simbol, ${fnNames.length} fungsi${fnNames.length ? ": " + fnNames.join(", ") : ""}`,
      ),
    );
  }

  if (options.showSemantic) {
    console.log(clr(C.gray, "\n  ── Laporan Semantik ──"));
    console.log("  Fungsi:", JSON.stringify(semReport.functions, null, 2));
  }

  // ── Step 4: Optimization ──────────────────────────────────────────
  console.log(clr(C.bold, "[ 4/5 ] Optimizer — Ngoptimasi AST..."));
  const optimizer = new Optimizer();
  const optimizedAst = optimizer.optimize(JSON.parse(JSON.stringify(ast)));
  result.optimized = optimizedAst;
  const optStats = optimizer.getStats();

  const totalOpt =
    optStats.constantsFolded +
    optStats.identitiesRemoved +
    optStats.deadCodeRemoved;
  console.log(clr(C.green, `  ✓ ${totalOpt} optimasi diterapin`));
  console.log(clr(C.gray, `    Constant folding: ${optStats.constantsFolded}`));
  console.log(
    clr(C.gray, `    Identity elim:    ${optStats.identitiesRemoved}`),
  );
  console.log(clr(C.gray, `    Dead code elim:   ${optStats.deadCodeRemoved}`));

  if (options.showOptimize) {
    console.log(clr(C.gray, "\n  ── AST Abis Optimasi ──"));
    console.log(ASTPrinter.print(optimizedAst));
  }

  // ── Step 5: Code Generation ───────────────────────────────────────
  console.log(
    clr(C.bold, "[ 5/5 ] Code Generator — Ngasilin JavaScript..."),
  );

  if (parseErrors.length > 0 || semReport.errors.length > 0) {
    console.log(clr(C.red, "  ✗ Code generation dilewat karena ada error"));
  } else {
    const codegen = new CodeGenerator({ header: true });
    const js = codegen.generate(optimizedAst);
    result.js = js;
    result.success = true;

    const lines = js.split("\n").length;
    console.log(clr(C.green, `  ✓ JavaScript dihasilin — ${lines} baris`));

    if (options.outFile) {
      fs.writeFileSync(options.outFile, js, "utf8");
      console.log(clr(C.green, `\n  ✓ Disimpen ke: ${options.outFile}`));
    }

    if (!options.outFile || options.showAll) {
      console.log(
        clr(C.gray, "\n── Output JavaScript ────────────────────────"),
      );
      console.log(js);
      console.log(clr(C.gray, "─────────────────────────────────────────────"));
    }
  }

  // ── Summary ───────────────────────────────────────────────────────
  console.log();
  if (result.success) {
    console.log(clr(C.green + C.bold, "✓ Compile SUKSES!"));
  } else {
    console.log(
      clr(C.red + C.bold, `✗ Compile GAGAL — ${result.errors.length} error`),
    );
  }
  console.log();

  return result;
}

// ── CLI Entry ─────────────────────────────────────────────────────────
function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args.includes("--help")) {
    showHelp();
    return;
  }

  const filePath = args[0];
  if (!fs.existsSync(filePath)) {
    console.error(clr(C.red, `✗ File kagak ketemu: ${filePath}`));
    process.exit(1);
  }

  const source = fs.readFileSync(filePath, "utf8");
  const options = {
    showTokens: args.includes("--tokens") || args.includes("--all"),
    showAST: args.includes("--ast") || args.includes("--all"),
    showSemantic: args.includes("--semantic") || args.includes("--all"),
    showOptimize: args.includes("--optimize") || args.includes("--all"),
    showAll: args.includes("--all"),
    outFile: null,
  };

  const outIdx = args.indexOf("--out");
  if (outIdx !== -1 && args[outIdx + 1]) {
    options.outFile = args[outIdx + 1];
  }

  const result = compile(source, options);
  process.exit(result.success ? 0 : 1);
}

main();

module.exports = { compile };