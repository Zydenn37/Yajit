/**
 * AST - Komponen 3
 * Tugas: Representasi & visualisasi Abstract Syntax Tree
 *
 * Bobot: 10% (struktur) + 10% (visualisasi)
 */

class ASTPrinter {
  /**
   * Print AST sebagai teks indented (buat CLI)
   */
  static print(node, indent = 0) {
    if (!node) return "";
    const pad = "  ".repeat(indent);
    const pad1 = "  ".repeat(indent + 1);
    let out = "";

    switch (node.type) {
      case "Program":
        out = `${pad}Program\n`;
        node.body.forEach((s) => (out += ASTPrinter.print(s, indent + 1)));
        break;

      case "FuncDecl":
        out = `${pad}FuncDecl: ${node.name}(${node.params.join(", ")})\n`;
        out += ASTPrinter.print(node.body, indent + 1);
        break;

      case "VarDecl":
        out = `${pad}VarDecl: ${node.name}\n`;
        if (node.init) out += ASTPrinter.print(node.init, indent + 1);
        break;

      case "Block":
        out = `${pad}Block\n`;
        node.body.forEach((s) => (out += ASTPrinter.print(s, indent + 1)));
        break;

      case "If":
        out = `${pad}If\n`;
        out += `${pad1}[test]\n` + ASTPrinter.print(node.test, indent + 2);
        out +=
          `${pad1}[then]\n` + ASTPrinter.print(node.consequent, indent + 2);
        if (node.alternate)
          out +=
            `${pad1}[else]\n` + ASTPrinter.print(node.alternate, indent + 2);
        break;

      case "While":
        out = `${pad}While\n`;
        out += `${pad1}[test]\n` + ASTPrinter.print(node.test, indent + 2);
        out += `${pad1}[body]\n` + ASTPrinter.print(node.body, indent + 2);
        break;

      case "For":
        out = `${pad}For\n`;
        out += `${pad1}[init]\n` + ASTPrinter.print(node.init, indent + 2);
        out += `${pad1}[test]\n` + ASTPrinter.print(node.test, indent + 2);
        out += `${pad1}[update]\n` + ASTPrinter.print(node.update, indent + 2);
        out += `${pad1}[body]\n` + ASTPrinter.print(node.body, indent + 2);
        break;

      case "Return":
        out = `${pad}Return\n`;
        if (node.value) out += ASTPrinter.print(node.value, indent + 1);
        break;

      case "Print":
        out = `${pad}Print\n`;
        node.args.forEach((a) => (out += ASTPrinter.print(a, indent + 1)));
        break;

      case "ExprStmt":
        out = `${pad}ExprStmt\n`;
        out += ASTPrinter.print(node.expr, indent + 1);
        break;

      case "Assign":
        out = `${pad}Assign\n`;
        out += `${pad1}[left]\n` + ASTPrinter.print(node.left, indent + 2);
        out += `${pad1}[right]\n` + ASTPrinter.print(node.right, indent + 2);
        break;

      case "BinOp":
        out = `${pad}BinOp: "${node.op}"\n`;
        out += ASTPrinter.print(node.left, indent + 1);
        out += ASTPrinter.print(node.right, indent + 1);
        break;

      case "Unary":
        out = `${pad}Unary: "${node.op}"\n`;
        out += ASTPrinter.print(node.operand, indent + 1);
        break;

      case "Postfix":
        out = `${pad}Postfix: "${node.op}"\n`;
        out += ASTPrinter.print(node.operand, indent + 1);
        break;

      case "Call":
        out = `${pad}Call\n`;
        out += `${pad1}[callee]\n` + ASTPrinter.print(node.callee, indent + 2);
        node.args.forEach((a, i) => {
          out += `${pad1}[arg${i}]\n` + ASTPrinter.print(a, indent + 2);
        });
        break;

      case "Index":
        out = `${pad}Index\n`;
        out += `${pad1}[object]\n` + ASTPrinter.print(node.object, indent + 2);
        out += `${pad1}[index]\n` + ASTPrinter.print(node.index, indent + 2);
        break;

      case "Member":
        out = `${pad}Member: .${node.property}\n`;
        out += ASTPrinter.print(node.object, indent + 1);
        break;

      case "ArrayLit":
        out = `${pad}ArrayLit[${node.elements.length}]\n`;
        node.elements.forEach((e) => (out += ASTPrinter.print(e, indent + 1)));
        break;

      case "Ident":
        out = `${pad}Ident: ${node.name}\n`;
        break;
      case "Num":
        out = `${pad}Num: ${node.value}\n`;
        break;
      case "Str":
        out = `${pad}Str: ${node.value}\n`;
        break;
      case "Bool":
        out = `${pad}Bool: ${node.value}\n`;
        break;
      case "Null":
        out = `${pad}Null\n`;
        break;
      case "Break":
        out = `${pad}Break\n`;
        break;
      case "Continue":
        out = `${pad}Continue\n`;
        break;

      default:
        out = `${pad}${node.type}\n`;
    }
    return out;
  }

  /**
   * Convert AST ke JSON (buat debugging / export)
   */
  static toJSON(node) {
    return JSON.stringify(node, null, 2);
  }

  /**
   * Itung statistik AST
   */
  static stats(node) {
    const counts = {};
    function walk(n) {
      if (!n || typeof n !== "object") return;
      if (n.type) counts[n.type] = (counts[n.type] || 0) + 1;
      for (const key of Object.keys(n)) {
        if (key === "type") continue;
        const val = n[key];
        if (Array.isArray(val)) val.forEach(walk);
        else if (val && typeof val === "object") walk(val);
      }
    }
    walk(node);
    return counts;
  }

  /**
   * Itung kedalaman AST
   */
  static depth(node) {
    if (!node || typeof node !== "object") return 0;
    let max = 0;
    for (const key of Object.keys(node)) {
      if (key === "type") continue;
      const val = node[key];
      if (Array.isArray(val)) {
        val.forEach((child) => {
          max = Math.max(max, ASTPrinter.depth(child));
        });
      } else if (val && typeof val === "object") {
        max = Math.max(max, ASTPrinter.depth(val));
      }
    }
    return 1 + max;
  }
}

module.exports = { ASTPrinter };