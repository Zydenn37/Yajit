/**
 * LEXER - Komponen 1
 * Tugas: Mecahin source code Base Betawi jadi token-token
 *
 * Bobot: 15%
 */

const KEYWORDS = {
  isi: "VAR",
  kalo: "IF",
  kalo_kagak: "ELSE",
  selame: "WHILE",
  buat: "FOR",
  fungsi: "FUNC",
  balikin: "RETURN",
  tulis: "PRINT",
  bener: "BOOL_TRUE",
  salah: "BOOL_FALSE",
  deretan: "ARRAY",
  ame: "AND",
  atau: "OR",
  kagak: "NOT",
  berhenti: "BREAK",
  lanjutin: "CONTINUE",
  null: "NULL",
};

const OPERATORS = [
  "<=",
  ">=",
  "==",
  "!=",
  "&&",
  "||",
  "++",
  "--",
  "+=",
  "-=",
  "*=",
  "/=",
  "+",
  "-",
  "*",
  "/",
  "%",
  "=",
  "<",
  ">",
  "!",
  "&",
  "|",
];

const PUNCTUATION = {
  "{": "LBRACE",
  "}": "RBRACE",
  "(": "LPAREN",
  ")": "RPAREN",
  "[": "LBRACKET",
  "]": "RBRACKET",
  ";": "SEMI",
  ",": "COMMA",
  ".": "DOT",
  ":": "COLON",
};

class Token {
  constructor(type, value, line, col) {
    this.type = type;
    this.value = value;
    this.line = line;
    this.col = col;
  }
  toString() {
    return `Token(${this.type}, "${this.value}", L${this.line}:C${this.col})`;
  }
}

class LexerError extends Error {
  constructor(msg, line, col) {
    super(`[Lexer] Baris ${line}:${col} — ${msg}`);
    this.line = line;
    this.col = col;
  }
}

class Lexer {
  constructor(source) {
    this.src = source;
    this.pos = 0;
    this.line = 1;
    this.col = 1;
    this.tokens = [];
    this.errors = [];
  }

  peek(offset = 0) {
    return this.src[this.pos + offset] || "";
  }

  advance() {
    const ch = this.src[this.pos++];
    if (ch === "\n") {
      this.line++;
      this.col = 1;
    } else {
      this.col++;
    }
    return ch;
  }

  skipWhitespace() {
    while (this.pos < this.src.length && /\s/.test(this.peek())) this.advance();
  }

  skipLineComment() {
    while (this.pos < this.src.length && this.peek() !== "\n") this.advance();
  }

  skipBlockComment() {
    while (this.pos < this.src.length) {
      if (this.peek() === "*" && this.peek(1) === "/") {
        this.advance();
        this.advance();
        return;
      }
      this.advance();
    }
    this.errors.push(
      new LexerError("Komentar blok kagak ditutup", this.line, this.col),
    );
  }

  readString(quote) {
    const startLine = this.line,
      startCol = this.col;
    this.advance(); // skip opening quote
    let str = "";
    while (this.pos < this.src.length && this.peek() !== quote) {
      if (this.peek() === "\\") {
        this.advance();
        const esc = this.advance();
        const escMap = {
          n: "\n",
          t: "\t",
          r: "\r",
          "\\": "\\",
          '"': '"',
          "'": "'",
        };
        str += escMap[esc] || "\\" + esc;
      } else {
        str += this.advance();
      }
    }
    if (this.peek() !== quote) {
      this.errors.push(
        new LexerError("String kagak ditutup", startLine, startCol),
      );
    } else {
      this.advance(); // skip closing quote
    }
    return new Token("STRING", JSON.stringify(str), startLine, startCol);
  }

  readNumber() {
    const startLine = this.line,
      startCol = this.col;
    let num = "";
    while (/\d/.test(this.peek())) num += this.advance();
    if (this.peek() === "." && /\d/.test(this.peek(1))) {
      num += this.advance();
      while (/\d/.test(this.peek())) num += this.advance();
    }
    return new Token("NUMBER", num, startLine, startCol);
  }

  readIdentOrKeyword() {
    const startLine = this.line,
      startCol = this.col;
    const IDENT_CONT = /[a-zA-Z_0-9]/;
    let word = "";
    while (this.pos < this.src.length && IDENT_CONT.test(this.peek()))
      word += this.advance();

    // Handle multi-word keyword: kalo_kagak
    if (word === "kalo" && this.peek() === "_") {
      const saved = this.pos;
      let rest = "";
      this.advance(); // skip _
      while (this.pos < this.src.length && IDENT_CONT.test(this.peek()))
        rest += this.advance();
      if (KEYWORDS["kalo_" + rest]) {
        word = "kalo_" + rest;
      } else {
        this.pos = saved;
      }
    }

    const type = KEYWORDS[word] || "IDENT";
    return new Token(type, word, startLine, startCol);
  }

  tokenize() {
    while (this.pos < this.src.length) {
      this.skipWhitespace();
      if (this.pos >= this.src.length) break;

      const ch = this.peek();
      const line = this.line;
      const col = this.col;

      // Line comment
      if (ch === "/" && this.peek(1) === "/") {
        this.skipLineComment();
        continue;
      }
      // Block comment
      if (ch === "/" && this.peek(1) === "*") {
        this.advance();
        this.advance();
        this.skipBlockComment();
        continue;
      }
      // String
      if (ch === '"' || ch === "'") {
        this.tokens.push(this.readString(ch));
        continue;
      }
      // Number
      if (/\d/.test(ch)) {
        this.tokens.push(this.readNumber());
        continue;
      }
      // Identifier / keyword
      if (/[a-zA-Z_]/.test(ch)) {
        this.tokens.push(this.readIdentOrKeyword());
        continue;
      }
      // Operator
      let matched = false;
      for (const op of OPERATORS) {
        if (this.src.startsWith(op, this.pos)) {
          this.tokens.push(new Token("OP", op, line, col));
          for (let i = 0; i < op.length; i++) this.advance();
          matched = true;
          break;
        }
      }
      if (matched) continue;
      // Punctuation
      if (PUNCTUATION[ch]) {
        this.tokens.push(new Token(PUNCTUATION[ch], ch, line, col));
        this.advance();
        continue;
      }

      this.errors.push(
        new LexerError(`Karakter kagak dikenal: '${ch}'`, line, col),
      );
      this.advance();
    }

    this.tokens.push(new Token("EOF", "", this.line, this.col));
    return { tokens: this.tokens, errors: this.errors };
  }
}

module.exports = { Lexer, Token, KEYWORDS };