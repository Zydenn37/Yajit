/**
 * CODE OPTIMIZER - Bagian dari Komponen 4
 * Tugas: Optimasi AST sebelum code generation
 * Teknik: Constant Folding, Identity Elimination, Dead Code Elimination
 *
 * Bobot: Bagian dari Semantic Analysis 10%
 */

class Optimizer {
  constructor() {
    this.stats = {
      constantsFolded: 0,
      identitiesRemoved: 0,
      deadCodeRemoved: 0,
    };
  }

  optimize(node) {
    if (!node || typeof node !== "object") return node;

    switch (node.type) {
      case "Program":
        return {
          ...node,
          body: node.body.map((s) => this.optimize(s)).filter(Boolean),
        };

      case "Block":
        return {
          ...node,
          body: node.body.map((s) => this.optimize(s)).filter(Boolean),
        };

      case "FuncDecl":
        return { ...node, body: this.optimize(node.body) };

      case "VarDecl":
        return { ...node, init: this.optimize(node.init) };

      case "If":
        return this.optimizeIf(node);

      case "While":
        return this.optimizeWhile(node);

      case "For":
        return {
          ...node,
          init: this.optimize(node.init),
          test: this.optimize(node.test),
          update: this.optimize(node.update),
          body: this.optimize(node.body),
        };

      case "Return":
        return { ...node, value: this.optimize(node.value) };

      case "Print":
        return { ...node, args: node.args.map((a) => this.optimize(a)) };

      case "ExprStmt":
        return { ...node, expr: this.optimize(node.expr) };

      case "Assign":
        return {
          ...node,
          left: this.optimize(node.left),
          right: this.optimize(node.right),
        };

      case "BinOp":
        return this.optimizeBinOp(node);

      case "Unary":
        return this.optimizeUnary(node);

      case "Call":
        return {
          ...node,
          callee: this.optimize(node.callee),
          args: node.args.map((a) => this.optimize(a)),
        };

      case "Index":
        return {
          ...node,
          object: this.optimize(node.object),
          index: this.optimize(node.index),
        };

      case "ArrayLit":
        return {
          ...node,
          elements: node.elements.map((e) => this.optimize(e)),
        };

      default:
        return node;
    }
  }

  optimizeBinOp(node) {
    const left = this.optimize(node.left);
    const right = this.optimize(node.right);
    const op = node.op;

    // ── Constant Folding ───────────────────────────────────────
    if (left.type === "Num" && right.type === "Num") {
      const l = left.value,
        r = right.value;
      const numOps = {
        "+": l + r,
        "-": l - r,
        "*": l * r,
        "/": r !== 0 ? l / r : null,
        "%": r !== 0 ? l % r : null,
        "<": l < r,
        ">": l > r,
        "<=": l <= r,
        ">=": l >= r,
        "==": l == r,
        "!=": l != r,
      };
      if (op in numOps && numOps[op] !== null) {
        this.stats.constantsFolded++;
        const val = numOps[op];
        return typeof val === "boolean"
          ? { type: "Bool", value: val }
          : { type: "Num", value: val };
      }
    }

    if (left.type === "Str" && right.type === "Str" && op === "+") {
      this.stats.constantsFolded++;
      const rawL = JSON.parse(left.value);
      const rawR = JSON.parse(right.value);
      return { type: "Str", value: JSON.stringify(rawL + rawR) };
    }

    if (left.type === "Bool" && right.type === "Bool") {
      if (op === "&&") {
        this.stats.constantsFolded++;
        return left.value ? right : { type: "Bool", value: false };
      }
      if (op === "||") {
        this.stats.constantsFolded++;
        return left.value ? { type: "Bool", value: true } : right;
      }
    }

    // ── Identity Elimination ────────────────────────────────────
    // x + 0 = x, x - 0 = x
    if (op === "+" && right.type === "Num" && right.value === 0) {
      this.stats.identitiesRemoved++;
      return left;
    }
    if (op === "+" && left.type === "Num" && left.value === 0) {
      this.stats.identitiesRemoved++;
      return right;
    }
    if (op === "-" && right.type === "Num" && right.value === 0) {
      this.stats.identitiesRemoved++;
      return left;
    }
    // x * 1 = x, 1 * x = x
    if (op === "*" && right.type === "Num" && right.value === 1) {
      this.stats.identitiesRemoved++;
      return left;
    }
    if (op === "*" && left.type === "Num" && left.value === 1) {
      this.stats.identitiesRemoved++;
      return right;
    }
    // x * 0 = 0, 0 * x = 0
    if (
      op === "*" &&
      ((left.type === "Num" && left.value === 0) ||
        (right.type === "Num" && right.value === 0))
    ) {
      this.stats.identitiesRemoved++;
      return { type: "Num", value: 0 };
    }
    // x / 1 = x
    if (op === "/" && right.type === "Num" && right.value === 1) {
      this.stats.identitiesRemoved++;
      return left;
    }

    return { ...node, left, right };
  }

  optimizeUnary(node) {
    const operand = this.optimize(node.operand);
    if (node.op === "-" && operand.type === "Num") {
      this.stats.constantsFolded++;
      return { type: "Num", value: -operand.value };
    }
    if (node.op === "!" && operand.type === "Bool") {
      this.stats.constantsFolded++;
      return { type: "Bool", value: !operand.value };
    }
    return { ...node, operand };
  }

  optimizeIf(node) {
    const test = this.optimize(node.test);
    // Dead code elimination: kalo (bener) / kalo (salah)
    if (test.type === "Bool") {
      this.stats.deadCodeRemoved++;
      if (test.value) return this.optimize(node.consequent);
      if (node.alternate) return this.optimize(node.alternate);
      return null;
    }
    return {
      ...node,
      test,
      consequent: this.optimize(node.consequent),
      alternate: this.optimize(node.alternate),
    };
  }

  optimizeWhile(node) {
    const test = this.optimize(node.test);
    // selame (salah) → dead code
    if (test.type === "Bool" && !test.value) {
      this.stats.deadCodeRemoved++;
      return null;
    }
    return { ...node, test, body: this.optimize(node.body) };
  }

  getStats() {
    return this.stats;
  }
}

module.exports = { Optimizer };