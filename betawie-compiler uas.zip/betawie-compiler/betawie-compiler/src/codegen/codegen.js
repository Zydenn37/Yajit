/**
 * CODE GENERATOR - Komponen 5
 * Tugas: Ngubah AST jadi kode JavaScript yang valid
 *
 * Bobot: 10%
 */

class CodeGenerator {
  constructor(options = {}) {
    this.indent = 0;
    this.output = [];
    this.options = {
      indentSize: options.indentSize || 2,
      semicolons: options.semicolons !== false,
      comments: options.comments !== false,
      header: options.header !== false,
    };
  }

  // ─── Helpers ────────────────────────────────────────────────────
  pad() {
    return " ".repeat(this.indent * this.options.indentSize);
  }
  push(line) {
    this.output.push(this.pad() + line);
  }
  nl() {
    this.output.push("");
  }
  sc() {
    return this.options.semicolons ? ";" : "";
  }
  indent1() {
    this.indent++;
  }
  dedent() {
    this.indent--;
  }

  // ─── Main ───────────────────────────────────────────────────────
  generate(node) {
    if (this.options.header) {
      this.output.push("// ================================================");
      this.output.push("// Dihasilin ame Kompiler Base Betawi → JavaScript");
      this.output.push(`// Tanggal: ${new Date().toLocaleString("id-ID")}`);
      this.output.push("// ================================================");
      this.nl();
    }
    this.genNode(node);
    return this.output.join("\n");
  }

  genNode(node) {
    if (!node) return "";
    switch (node.type) {
      case "Program":
        return this.genProgram(node);
      case "FuncDecl":
        return this.genFuncDecl(node);
      case "VarDecl":
        return this.genVarDecl(node);
      case "Block":
        return this.genBlock(node);
      case "If":
        return this.genIf(node);
      case "While":
        return this.genWhile(node);
      case "For":
        return this.genFor(node);
      case "Return":
        return this.genReturn(node);
      case "Print":
        return this.genPrint(node);
      case "ExprStmt":
        return this.genExprStmt(node);
      case "Break":
        this.push(`break${this.sc()}`);
        break;
      case "Continue":
        this.push(`continue${this.sc()}`);
        break;
      default:
        return "";
    }
  }

  genProgram(node) {
    node.body.forEach((s, i) => {
      this.genNode(s);
      // Baris kosong abis deklarasi fungsi
      if (s.type === "FuncDecl" && i < node.body.length - 1) this.nl();
    });
  }

  genFuncDecl(node) {
    this.push(`function ${node.name}(${node.params.join(", ")}) {`);
    this.indent1();
    node.body.body.forEach((s) => this.genNode(s));
    this.dedent();
    this.push("}");
  }

  genVarDecl(node) {
    const init = node.init ? ` = ${this.genExpr(node.init)}` : "";
    this.push(`let ${node.name}${init}${this.sc()}`);
  }

  genBlock(node) {
    node.body.forEach((s) => this.genNode(s));
  }

  genIf(node) {
    this.push(`if (${this.genExpr(node.test)}) {`);
    this.indent1();
    this.genNode(node.consequent);
    this.dedent();
    if (node.alternate) {
      if (node.alternate.type === "If") {
        this.push("} else");
        this.genIf(node.alternate);
        return;
      }
      this.push("} else {");
      this.indent1();
      this.genNode(node.alternate);
      this.dedent();
    }
    this.push("}");
  }

  genWhile(node) {
    this.push(`while (${this.genExpr(node.test)}) {`);
    this.indent1();
    this.genNode(node.body);
    this.dedent();
    this.push("}");
  }

  genFor(node) {
    const init = node.init ? this.genForInit(node.init) : "";
    const test = node.test ? this.genExpr(node.test) : "";
    const update = node.update ? this.genExpr(node.update) : "";
    this.push(`for (${init}; ${test}; ${update}) {`);
    this.indent1();
    this.genNode(node.body);
    this.dedent();
    this.push("}");
  }

  genForInit(node) {
    if (node.type === "VarDecl") {
      const init = node.init ? ` = ${this.genExpr(node.init)}` : "";
      return `let ${node.name}${init}`;
    }
    return this.genExpr(node.expr || node);
  }

  genReturn(node) {
    const val = node.value ? ` ${this.genExpr(node.value)}` : "";
    this.push(`return${val}${this.sc()}`);
  }

  genPrint(node) {
    const args = node.args.map((a) => this.genExpr(a)).join(", ");
    this.push(`console.log(${args})${this.sc()}`);
  }

  genExprStmt(node) {
    this.push(`${this.genExpr(node.expr)}${this.sc()}`);
  }

  // ─── Expression Generator (returns string) ───────────────────────
  genExpr(node) {
    if (!node) return "";
    switch (node.type) {
      case "Assign":
        return `${this.genExpr(node.left)} = ${this.genExpr(node.right)}`;
      case "BinOp":
        return `(${this.genExpr(node.left)} ${node.op} ${this.genExpr(node.right)})`;
      case "Unary":
        return `${node.op}(${this.genExpr(node.operand)})`;
      case "Postfix":
        return `${this.genExpr(node.operand)}${node.op}`;
      case "Call":
        return `${this.genExpr(node.callee)}(${node.args.map((a) => this.genExpr(a)).join(", ")})`;
      case "Index":
        return `${this.genExpr(node.object)}[${this.genExpr(node.index)}]`;
      case "Member":
        return `${this.genExpr(node.object)}.${node.property}`;
      case "ArrayLit":
        return `[${node.elements.map((e) => this.genExpr(e)).join(", ")}]`;
      case "Ident":
        return node.name;
      case "Num":
        return String(node.value);
      case "Str":
        return node.value; // udah JSON-stringified
      case "Bool":
        return String(node.value);
      case "Null":
        return "null";
      default:
        return "";
    }
  }
}

module.exports = { CodeGenerator };