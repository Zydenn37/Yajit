# Desain Base Betawi — Grammar (BNF/CFG)

# Bobot: 10%

## Deskripsi

Betawi Compiler (BC) adalah base pemrograman mini yang make
keyword dari Base Betawi. Dibikin buat pendidikan & demonstrasi konsep kompiler.

---

## Keyword & Terjemahan

| Base Betawi | JavaScript  | Keterangan                |
| ----------- | ----------- | ------------------------- |
| isi         | let/var     | Deklarasi variabel        |
| kalo        | if          | Percabangan               |
| kalo_kagak  | else        | Alternatif percabangan    |
| selame      | while       | Perulangan kondisional    |
| buat        | for         | Perulangan terstruktur    |
| fungsi      | function    | Deklarasi fungsi          |
| balikin     | return      | Nilai kembalian           |
| tulis       | console.log | Output/cetak              |
| bener       | true        | Nilai boolean bener       |
| salah       | false       | Nilai boolean salah       |
| deretan     | array/[]    | Tipe data larik           |
| ame         | &&          | Operator logika DAN       |
| atau        | \|\|        | Operator logika ATAU      |
| kagak       | !           | Operator logika TIDAK     |
| berhenti    | break       | Keluar dari loop          |
| lanjutin    | continue    | Lanjut iterasi berikutnya |

---

## Grammar Formal (BNF)

```
Program      ::= Statement*

Statement    ::= FuncDecl
             | VarDecl
             | IfStmt
             | WhileStmt
             | ForStmt
             | ReturnStmt
             | PrintStmt
             | BreakStmt
             | ContinueStmt
             | Block
             | ExprStmt

FuncDecl     ::= "fungsi" IDENT "(" ParamList? ")" Block
ParamList    ::= IDENT ("," IDENT)*

VarDecl      ::= "isi" IDENT ("=" Expr)?

IfStmt       ::= "kalo" "(" Expr ")" Block
               ("kalo_kagak" (IfStmt | Block))?

WhileStmt    ::= "selame" "(" Expr ")" Block

ForStmt      ::= "buat" "(" ForInit? ";" Expr? ";" Expr? ")" Block
ForInit      ::= VarDecl | Expr

ReturnStmt   ::= "balikin" Expr?

PrintStmt    ::= "tulis" "(" ArgList? ")"

BreakStmt    ::= "berhenti"
ContinueStmt ::= "lanjutin"

Block        ::= "{" Statement* "}"

ExprStmt     ::= Expr ";"?

ArgList      ::= Expr ("," Expr)*

Expr         ::= Assign
Assign       ::= Or (("=" | "+=" | "-=" | "*=" | "/=") Assign)?
Or           ::= And (("||" | "atau") And)*
And          ::= Equality (("&&" | "ame") Equality)*
Equality     ::= Relational (("==" | "!=") Relational)*
Relational   ::= Additive (("<" | ">" | "<=" | ">=") Additive)*
Additive     ::= Mult (("+" | "-") Mult)*
Mult         ::= Unary (("*" | "/" | "%") Unary)*
Unary        ::= ("-" | "!" | "kagak") Unary
             | Postfix
Postfix      ::= Call ("++" | "--")?
Call         ::= Primary (CallSuffix)*
CallSuffix   ::= "(" ArgList? ")"
             | "[" Expr "]"
             | "." IDENT

Primary      ::= NUMBER
             | STRING
             | "bener"
             | "salah"
             | "null"
             | "deretan" "[" ArgList? "]"
             | IDENT
             | "(" Expr ")"

IDENT        ::= [a-zA-Z_][a-zA-Z0-9_]*
NUMBER       ::= [0-9]+ ("." [0-9]+)?
STRING       ::= '"' [^"]* '"' | "'" [^']* "'"
```

---

## Contoh Program

```betawi
// Variabel
isi x = 10
isi name = "Mpok"
isi arr = deretan[1, 2, 3, 4, 5]

// Percabangan
kalo (x > 5) {
  tulis("gede")
} kalo_kagak {
  tulis("kecil")
}

// Loop
selame (x > 0) {
  tulis(x)
  x = x - 1
}

// Fungsi
fungsi tambah(a, b) {
  balikin a + b
}
tulis(tambah(3, 4))
```

---

## Pipeline Kompiler

```
Source Code (.betawi)
      ↓
  [1] LEXER          → Token List
      ↓
  [2] PARSER         → AST (Abstract Syntax Tree)
      ↓
  [3] SEMANTIC       → Validated AST + Symbol Table
      ↓
  [4] OPTIMIZER      → Optimized AST
      ↓
  [5] CODE GEN       → JavaScript (.js)
```
